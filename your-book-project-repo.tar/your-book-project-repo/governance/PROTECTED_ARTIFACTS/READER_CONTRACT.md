# Reader Contract

This document defines the expected relationship and commitment between the project and its readers.

## Terms
<!-- Placeholder for terms -->
