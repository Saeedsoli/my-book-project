# Accuracy and Source Verification

Policy on ensuring factual accuracy and citing sources.

## Policy
<!-- Placeholder for policy details -->
