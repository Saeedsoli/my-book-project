# Governance Proposals

This directory holds formal proposals for changes to the project's governance.

## Format
<!-- Placeholder for proposal format -->
