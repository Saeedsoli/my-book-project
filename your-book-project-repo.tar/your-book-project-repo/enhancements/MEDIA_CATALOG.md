# Media Catalog

A catalog of all media assets (images, videos, etc.) used in the book.

## Format
<!-- Placeholder for catalog format -->
